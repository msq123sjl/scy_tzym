#ifndef SPI_DRIVERS_H
#define SPI_DRIVERS_H

void SPI_Init();
int  spi_read_ad();

#endif // ADS1256_DRIVERS_H
